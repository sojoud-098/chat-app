# Flutter Chat


![photo_2020-10-24_22-54-13](https://user-images.githubusercontent.com/42120995/97092363-2b9d8080-164c-11eb-8dcf-8bcc7ed613a4.jpg)
![photo_2020-10-24_22-54-17](https://user-images.githubusercontent.com/42120995/97092365-2c361700-164c-11eb-8704-9a40482425e3.jpg)
![photo_2020-10-24_22-54-21](https://user-images.githubusercontent.com/42120995/97092366-2ccead80-164c-11eb-9de0-9b86d0137a57.jpg)

